/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/admin/Desktop/50169236/project1/project1/sorting_part.v";
static unsigned int ng1[] = {1U, 0U};
static int ng2[] = {0, 0};
static int ng3[] = {1, 0};
static int ng4[] = {2, 0};
static int ng5[] = {3, 0};



static void Always_42_0(char *t0)
{
    char t6[8];
    char t30[8];
    char t31[8];
    char t61[8];
    char t62[8];
    char t70[8];
    char t81[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    int t41;
    char *t42;
    unsigned int t43;
    int t44;
    int t45;
    unsigned int t46;
    unsigned int t47;
    int t48;
    int t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    char *t82;

LAB0:    t1 = (t0 + 4448U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 4768);
    *((int *)t2) = 1;
    t3 = (t0 + 4480);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(43, ng0);

LAB5:    xsi_set_current_line(44, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t4 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t4);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB9;

LAB6:    if (t18 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t6) = 1;

LAB9:    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB10;

LAB11:
LAB12:    goto LAB2;

LAB8:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(45, ng0);

LAB13:    xsi_set_current_line(46, ng0);
    t28 = (t0 + 1368U);
    t29 = *((char **)t28);
    t28 = (t0 + 3048);
    t32 = (t0 + 3048);
    t33 = (t32 + 72U);
    t34 = *((char **)t33);
    t35 = (t0 + 3048);
    t36 = (t35 + 64U);
    t37 = *((char **)t36);
    t38 = ((char*)((ng2)));
    xsi_vlog_generic_convert_array_indices(t30, t31, t34, t37, 2, 1, t38, 32, 1);
    t39 = (t30 + 4);
    t40 = *((unsigned int *)t39);
    t41 = (!(t40));
    t42 = (t31 + 4);
    t43 = *((unsigned int *)t42);
    t44 = (!(t43));
    t45 = (t41 && t44);
    if (t45 == 1)
        goto LAB14;

LAB15:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = (t0 + 3048);
    t4 = (t0 + 3048);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t8 = (t0 + 3048);
    t21 = (t8 + 64U);
    t22 = *((char **)t21);
    t28 = ((char*)((ng3)));
    xsi_vlog_generic_convert_array_indices(t6, t30, t7, t22, 2, 1, t28, 32, 1);
    t29 = (t6 + 4);
    t9 = *((unsigned int *)t29);
    t41 = (!(t9));
    t32 = (t30 + 4);
    t10 = *((unsigned int *)t32);
    t44 = (!(t10));
    t45 = (t41 && t44);
    if (t45 == 1)
        goto LAB16;

LAB17:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 3048);
    t4 = (t0 + 3048);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t8 = (t0 + 3048);
    t21 = (t8 + 64U);
    t22 = *((char **)t21);
    t28 = ((char*)((ng4)));
    xsi_vlog_generic_convert_array_indices(t6, t30, t7, t22, 2, 1, t28, 32, 1);
    t29 = (t6 + 4);
    t9 = *((unsigned int *)t29);
    t41 = (!(t9));
    t32 = (t30 + 4);
    t10 = *((unsigned int *)t32);
    t44 = (!(t10));
    t45 = (t41 && t44);
    if (t45 == 1)
        goto LAB18;

LAB19:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1848U);
    t3 = *((char **)t2);
    t2 = (t0 + 3048);
    t4 = (t0 + 3048);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t8 = (t0 + 3048);
    t21 = (t8 + 64U);
    t22 = *((char **)t21);
    t28 = ((char*)((ng5)));
    xsi_vlog_generic_convert_array_indices(t6, t30, t7, t22, 2, 1, t28, 32, 1);
    t29 = (t6 + 4);
    t9 = *((unsigned int *)t29);
    t41 = (!(t9));
    t32 = (t30 + 4);
    t10 = *((unsigned int *)t32);
    t44 = (!(t10));
    t45 = (t41 && t44);
    if (t45 == 1)
        goto LAB20;

LAB21:    xsi_set_current_line(51, ng0);
    xsi_set_current_line(51, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3208);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB22:    t2 = (t0 + 3208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t6);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB23;

LAB24:    xsi_set_current_line(64, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    t7 = (t5 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 3048);
    t22 = (t21 + 64U);
    t28 = *((char **)t22);
    t29 = ((char*)((ng2)));
    xsi_vlog_generic_get_array_select_value(t6, 4, t4, t8, t28, 2, 1, t29, 32, 1);
    t32 = (t0 + 2248);
    xsi_vlogvar_assign_value(t32, t6, 0, 0, 4);
    xsi_set_current_line(65, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    t7 = (t5 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 3048);
    t22 = (t21 + 64U);
    t28 = *((char **)t22);
    t29 = ((char*)((ng3)));
    xsi_vlog_generic_get_array_select_value(t6, 4, t4, t8, t28, 2, 1, t29, 32, 1);
    t32 = (t0 + 2408);
    xsi_vlogvar_assign_value(t32, t6, 0, 0, 4);
    xsi_set_current_line(66, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    t7 = (t5 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 3048);
    t22 = (t21 + 64U);
    t28 = *((char **)t22);
    t29 = ((char*)((ng4)));
    xsi_vlog_generic_get_array_select_value(t6, 4, t4, t8, t28, 2, 1, t29, 32, 1);
    t32 = (t0 + 2568);
    xsi_vlogvar_assign_value(t32, t6, 0, 0, 4);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    t7 = (t5 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 3048);
    t22 = (t21 + 64U);
    t28 = *((char **)t22);
    t29 = ((char*)((ng5)));
    xsi_vlog_generic_get_array_select_value(t6, 4, t4, t8, t28, 2, 1, t29, 32, 1);
    t32 = (t0 + 2728);
    xsi_vlogvar_assign_value(t32, t6, 0, 0, 4);
    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB12;

LAB14:    t46 = *((unsigned int *)t30);
    t47 = *((unsigned int *)t31);
    t48 = (t46 - t47);
    t49 = (t48 + 1);
    xsi_vlogvar_assign_value(t28, t29, 0, *((unsigned int *)t31), t49);
    goto LAB15;

LAB16:    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t30);
    t48 = (t11 - t12);
    t49 = (t48 + 1);
    xsi_vlogvar_assign_value(t2, t3, 0, *((unsigned int *)t30), t49);
    goto LAB17;

LAB18:    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t30);
    t48 = (t11 - t12);
    t49 = (t48 + 1);
    xsi_vlogvar_assign_value(t2, t3, 0, *((unsigned int *)t30), t49);
    goto LAB19;

LAB20:    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t30);
    t48 = (t11 - t12);
    t49 = (t48 + 1);
    xsi_vlogvar_assign_value(t2, t3, 0, *((unsigned int *)t30), t49);
    goto LAB21;

LAB23:    xsi_set_current_line(52, ng0);

LAB25:    xsi_set_current_line(53, ng0);
    xsi_set_current_line(53, ng0);
    t8 = ((char*)((ng2)));
    t21 = (t0 + 3368);
    xsi_vlogvar_assign_value(t21, t8, 0, 0, 32);

LAB26:    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t6);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB27;

LAB28:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 3208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB22;

LAB27:    xsi_set_current_line(54, ng0);

LAB29:    xsi_set_current_line(55, ng0);
    t8 = (t0 + 3048);
    t21 = (t8 + 56U);
    t22 = *((char **)t21);
    t28 = (t0 + 3048);
    t29 = (t28 + 72U);
    t32 = *((char **)t29);
    t33 = (t0 + 3048);
    t34 = (t33 + 64U);
    t35 = *((char **)t34);
    t36 = (t0 + 3368);
    t37 = (t36 + 56U);
    t38 = *((char **)t37);
    xsi_vlog_generic_get_array_select_value(t30, 4, t22, t32, t35, 2, 1, t38, 32, 1);
    t39 = (t0 + 3048);
    t42 = (t39 + 56U);
    t50 = *((char **)t42);
    t51 = (t0 + 3048);
    t52 = (t51 + 72U);
    t53 = *((char **)t52);
    t54 = (t0 + 3048);
    t55 = (t54 + 64U);
    t56 = *((char **)t55);
    t57 = (t0 + 3368);
    t58 = (t57 + 56U);
    t59 = *((char **)t58);
    t60 = ((char*)((ng3)));
    memset(t61, 0, 8);
    xsi_vlog_signed_add(t61, 32, t59, 32, t60, 32);
    xsi_vlog_generic_get_array_select_value(t31, 4, t50, t53, t56, 2, 1, t61, 32, 1);
    memset(t62, 0, 8);
    t63 = (t30 + 4);
    if (*((unsigned int *)t63) != 0)
        goto LAB31;

LAB30:    t64 = (t31 + 4);
    if (*((unsigned int *)t64) != 0)
        goto LAB31;

LAB34:    if (*((unsigned int *)t30) > *((unsigned int *)t31))
        goto LAB32;

LAB33:    t66 = (t62 + 4);
    t14 = *((unsigned int *)t66);
    t15 = (~(t14));
    t16 = *((unsigned int *)t62);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB35;

LAB36:
LAB37:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 3368);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB26;

LAB31:    t65 = (t62 + 4);
    *((unsigned int *)t62) = 1;
    *((unsigned int *)t65) = 1;
    goto LAB33;

LAB32:    *((unsigned int *)t62) = 1;
    goto LAB33;

LAB35:    xsi_set_current_line(56, ng0);

LAB38:    xsi_set_current_line(57, ng0);
    t67 = (t0 + 3048);
    t68 = (t67 + 56U);
    t69 = *((char **)t68);
    t71 = (t0 + 3048);
    t72 = (t71 + 72U);
    t73 = *((char **)t72);
    t74 = (t0 + 3048);
    t75 = (t74 + 64U);
    t76 = *((char **)t75);
    t77 = (t0 + 3368);
    t78 = (t77 + 56U);
    t79 = *((char **)t78);
    t80 = ((char*)((ng3)));
    memset(t81, 0, 8);
    xsi_vlog_signed_add(t81, 32, t79, 32, t80, 32);
    xsi_vlog_generic_get_array_select_value(t70, 4, t69, t73, t76, 2, 1, t81, 32, 1);
    t82 = (t0 + 3528);
    xsi_vlogvar_assign_value(t82, t70, 0, 0, 4);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    t7 = (t5 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 3048);
    t22 = (t21 + 64U);
    t28 = *((char **)t22);
    t29 = (t0 + 3368);
    t32 = (t29 + 56U);
    t33 = *((char **)t32);
    xsi_vlog_generic_get_array_select_value(t6, 4, t4, t8, t28, 2, 1, t33, 32, 1);
    t34 = (t0 + 3048);
    t35 = (t0 + 3048);
    t36 = (t35 + 72U);
    t37 = *((char **)t36);
    t38 = (t0 + 3048);
    t39 = (t38 + 64U);
    t42 = *((char **)t39);
    t50 = (t0 + 3368);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    t53 = ((char*)((ng3)));
    memset(t61, 0, 8);
    xsi_vlog_signed_add(t61, 32, t52, 32, t53, 32);
    xsi_vlog_generic_convert_array_indices(t30, t31, t37, t42, 2, 1, t61, 32, 1);
    t54 = (t30 + 4);
    t9 = *((unsigned int *)t54);
    t41 = (!(t9));
    t55 = (t31 + 4);
    t10 = *((unsigned int *)t55);
    t44 = (!(t10));
    t45 = (t41 && t44);
    if (t45 == 1)
        goto LAB39;

LAB40:    xsi_set_current_line(59, ng0);
    t2 = (t0 + 3528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    t7 = (t0 + 3048);
    t8 = (t7 + 72U);
    t21 = *((char **)t8);
    t22 = (t0 + 3048);
    t28 = (t22 + 64U);
    t29 = *((char **)t28);
    t32 = (t0 + 3368);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    xsi_vlog_generic_convert_array_indices(t6, t30, t21, t29, 2, 1, t34, 32, 1);
    t35 = (t6 + 4);
    t9 = *((unsigned int *)t35);
    t41 = (!(t9));
    t36 = (t30 + 4);
    t10 = *((unsigned int *)t36);
    t44 = (!(t10));
    t45 = (t41 && t44);
    if (t45 == 1)
        goto LAB41;

LAB42:    goto LAB37;

LAB39:    t11 = *((unsigned int *)t30);
    t12 = *((unsigned int *)t31);
    t48 = (t11 - t12);
    t49 = (t48 + 1);
    xsi_vlogvar_assign_value(t34, t6, 0, *((unsigned int *)t31), t49);
    goto LAB40;

LAB41:    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t30);
    t48 = (t11 - t12);
    t49 = (t48 + 1);
    xsi_vlogvar_assign_value(t5, t4, 0, *((unsigned int *)t30), t49);
    goto LAB42;

}


extern void work_m_00000000000647506800_0433454861_init()
{
	static char *pe[] = {(void *)Always_42_0};
	xsi_register_didat("work_m_00000000000647506800_0433454861", "isim/test_project1_isim_beh.exe.sim/work/m_00000000000647506800_0433454861.didat");
	xsi_register_executes(pe);
}
